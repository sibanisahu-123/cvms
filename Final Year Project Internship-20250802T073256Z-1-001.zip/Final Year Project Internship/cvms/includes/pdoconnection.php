<?php 
$conn = new PDO('mysql:host=localhost;dbname=cvmsdb','root','');
?>