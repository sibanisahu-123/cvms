<aside class="menu-sidebar d-none d-lg-block">
    <div class="logo">

        <h1>CVMS</h1>
    </div>
    <div class="menu-sidebar__content js-scrollbar1">
        <nav class="navbar-sidebar">
            <ul class="list-unstyled navbar__list">
                <li>
                    <a href="dashboard.php" style="color: blue">
                        <i class="fas fa-tachometer-alt"></i>Dashboard</a>
                </li>
                <li>
                    <a href="department-form.php" style="color: blue">
                        <i class="fa fa-cubes"></i>Department Details</a>
                </li>
                <li>
                    <a href="employee-details.php" style="color: blue">
                        <i class="fa fa-user"></i>Employee</a>
                </li>
               
                <li>
                    <a href="gate-form.php" style="color: blue">
                        <i class="fa fa-home"></i>Gate</a>
                </li>
                <li>
                    <a href="user-details.php" style="color: blue">
                        <i class="fa fa-user"></i>User</a>
                </li>
                <li>
                    <a href="reason-form.php" style="color: blue">
                        <i class="fa fa-question"></i>Reason</a>
                </li>

                <li>
                    <a href="current-visitors.php" style="color: blue">
                        <i class="fa fa-file"></i>Current Visitors Report</a>
                </li>

                <li>
                    <a href="ID-Proof-Report.php" style="color: blue">
                        <i class="fa fa-file"></i>Visitor's ID Wise Report</a>
                </li>

                <li>
                    <a href="departmentWise-Report.php" style="color: blue">
                        <i class="fa fa-file"></i>Department Wise Report</a>
                </li>

                <li>
                    <a href="bwdates-reports.php" style="color: blue">
                        <i class="fas fa-copy"></i>Date Wise Report</a>
                </li>

            </ul>
        </nav>
    </div>
</aside>