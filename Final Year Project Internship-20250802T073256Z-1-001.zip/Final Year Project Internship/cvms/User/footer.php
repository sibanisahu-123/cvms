<div class="row">
    <div class="col-md-4">
        <div class="copyright">
            <p>&copy; CVMS . All rights reserved.</p>
        </div>
    </div>
    <div class="col-md-4"></div>
    <div class="col-md-4">
        <p>Developed By <a href="http://inss.in">Interface Software Services</a>.</p>
    </div>
</div>