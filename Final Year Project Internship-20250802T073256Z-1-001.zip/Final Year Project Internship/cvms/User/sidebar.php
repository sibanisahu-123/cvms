<aside class="menu-sidebar d-none d-lg-block">
    <div class="logo">

        <h1>CVMS</h1>
    </div>
    <div class="menu-sidebar__content js-scrollbar1">
        <nav class="navbar-sidebar">
            <ul class="list-unstyled navbar__list">
                <li>
                    <a href="dashboard.php" style="color: blue">
                        <i class="fas fa-tachometer-alt"></i>Dashboard</a>
                </li>
                
                <li>
                    <a href="visitors-form.php" style="color: blue">
                        <i class="fa fa-plus"></i>New Visitor</a>
                </li>
                <li>
                    <a href="visitor-detail.php" style="color: blue">
                        <i class="fa fa-file"></i>Current Visitors List</a>
                </li>
                <li>
                    <a href="ID-Proof-Report.php" style="color: blue">
                        <i class="fa fa-file"></i>Visitor's ID Wise Report</a>
                </li>
                <li>
                    <a href="bwdates-reports.php" style="color: blue">
                        <i class="fa fa-file"></i>Date Wise Report</a>
                </li>
                <li>
                    <a href="change-password.php" style="color: blue">
                        <i class="fa fa-key"></i> Change Password</a>
                </li>
                <li>
                    <a href="logout.php" style="color: blue">
                        <i class="fa fa-lock"></i>Logout</a>
                </li>

            </ul>
        </nav>
    </div>
</aside>